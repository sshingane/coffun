// Include body scripts in the right order
// They will be concatenated using gulp-rigger in body.min.js

//= vendor/jquery.js
//= lib/jquery.navkit.js
//= lib/jquery.portfolio.js
